# ponytail: RNN-LSTM model — ResNet-18 features → BiLSTM → Attention → 7-class classifier
import os
import torch
import torch.nn as nn
import torchvision.models as models
import logging

logger = logging.getLogger(__name__)

NUM_CLASSES = 7


class CNNFeatureExtractor(nn.Module):
    """ResNet-18 backbone → spatial feature sequence (B, H*W, 512)."""
    def __init__(self):
        super().__init__()
        resnet = models.resnet18(weights=None)
        self.features = nn.Sequential(*list(resnet.children())[:-2])
        self.feat_dim = 512

    def forward(self, x):
        feat_map = self.features(x)
        B, C, H, W = feat_map.shape
        return feat_map.view(B, C, H * W).permute(0, 2, 1)


class DermoLSTMClassifier(nn.Module):
    """CNN → spatial patch sequence → BiLSTM → attention → classifier."""
    def __init__(self, num_classes=NUM_CLASSES, hidden_size=256, num_layers=2, dropout=0.3):
        super().__init__()
        self.cnn = CNNFeatureExtractor()

        self.lstm = nn.LSTM(
            input_size=self.cnn.feat_dim, hidden_size=hidden_size,
            num_layers=num_layers, batch_first=True, bidirectional=True,
            dropout=dropout if num_layers > 1 else 0.0
        )

        self.attention = nn.Sequential(
            nn.Linear(hidden_size * 2, 128), nn.Tanh(), nn.Linear(128, 1)
        )

        self.classifier = nn.Sequential(
            nn.LayerNorm(hidden_size * 2), nn.Dropout(dropout),
            nn.Linear(hidden_size * 2, 128), nn.GELU(),
            nn.Dropout(dropout * 0.5), nn.Linear(128, num_classes)
        )

    def freeze_cnn(self):
        for param in self.cnn.parameters():
            param.requires_grad = False

    def unfreeze_cnn(self):
        for param in self.cnn.parameters():
            param.requires_grad = True

    def forward(self, x):
        seq = self.cnn(x)
        lstm_out, _ = self.lstm(seq)
        attn_weights = torch.softmax(self.attention(lstm_out), dim=1)
        context = torch.sum(attn_weights * lstm_out, dim=1)
        return self.classifier(context)


def load_rnn_model(weights_path=None, device=None):
    """Load RNN-LSTM model, returns (model, status_msg)."""
    if device is None:
        device = 'cuda' if torch.cuda.is_available() else 'cpu'

    model = DermoLSTMClassifier(num_classes=NUM_CLASSES)

    default_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'models', 'rnn_best_model.pth')
    target = weights_path if weights_path and os.path.exists(weights_path) else default_path

    status = ""
    if os.path.exists(target):
        try:
            model.load_state_dict(torch.load(target, map_location=device, weights_only=True))
            status = f"Loaded RNN-LSTM checkpoint from {target}"
        except Exception as e:
            status = f"RNN initialized with random weights ({e})"
            logger.warning(status)
    else:
        status = f"RNN-LSTM initialized (num_classes={NUM_CLASSES}). No pretrained weights."
        logger.info(status)

    model.to(device).eval()
    return model, status


def count_parameters(model):
    """Returns dict with total/trainable/frozen param counts."""
    total = sum(p.numel() for p in model.parameters())
    trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
    return {
        'total': total, 'trainable': trainable, 'frozen': total - trainable,
        'total_millions': round(total / 1e6, 2),
        'trainable_millions': round(trainable / 1e6, 2)
    }
