# ponytail: FastAPI server — multi-model inference with Grad-CAM
import os, io, torch, logging
from contextlib import asynccontextmanager
from PIL import Image
from fastapi import FastAPI, File, UploadFile, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import JSONResponse

from src.model import load_model, load_any_model
from src.predict import predict_lesion_image
from src.severity import LESION_CLASSES, CLASS_LIST

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("DermoApp")

device = 'cuda' if torch.cuda.is_available() else 'cpu'
model, model_status = None, ""
rnn_model, rnn_status = None, ""

@asynccontextmanager
async def lifespan(app: FastAPI):
    global model, model_status, rnn_model, rnn_status
    try:
        model, model_status = load_model(weights_path=os.path.join(os.path.dirname(__file__), "..", "models", "best_model.pth"), device=device)
    except Exception as e:
        model_status = f"EfficientNet load error: {e}"
    try:
        rnn_model, rnn_status = load_any_model('rnn', weights_path=os.path.join(os.path.dirname(__file__), "..", "models", "rnn_best_model.pth"), device=device)
    except Exception as e:
        rnn_status = f"RNN not available: {e}"
    yield

app = FastAPI(title="DermoLens AI", version="2.0.0", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

@app.get("/health")
@app.get("/api/health")
def health():
    return {"status": "healthy", "device": device, "models": {
        "efficientnet": {"loaded": model is not None, "status": model_status},
        "rnn": {"loaded": rnn_model is not None, "status": rnn_status}
    }}

@app.get("/classes")
@app.get("/api/classes")
def classes():
    return {"count": len(LESION_CLASSES), "class_list": CLASS_LIST, "classes": LESION_CLASSES}

@app.get("/models")
@app.get("/api/models")
def models_list():
    return {"available": ["efficientnet", "rnn"], "default": "efficientnet"}

@app.post("/predict")
@app.post("/api/predict")
async def predict(file: UploadFile = File(...), model_type: str = Query("efficientnet")):
    sel = rnn_model if model_type == 'rnn' else model
    if sel is None:
        raise HTTPException(500, f"{model_type} model not loaded")
    if not file.content_type.startswith("image/"):
        raise HTTPException(400, "Upload an image file (JPEG, PNG, WEBP)")

    try:
        image = Image.open(io.BytesIO(await file.read())).convert("RGB")
        r = predict_lesion_image(sel, image, device=device)
        vis = r['visualizations']
        return JSONResponse({
            "prediction": r['prediction']['name'], "confidence": round(r['prediction']['confidence'], 3),
            "severity": r['severity']['risk_level'], "heatmap": vis['gradcam_heatmap_b64'] or vis['gradcam_overlay_b64'],
            "original_image": vis['original_b64'], "overlay": vis['gradcam_overlay_b64'],
            "class_code": r['prediction']['class_code'], "risk_level": r['prediction']['risk_level'],
            "severity_details": r['severity'], "class_probabilities": r['class_probabilities'],
            "model_used": model_type, "success": True
        })
    except Exception as e:
        logger.error(f"Predict failed: {e}", exc_info=True)
        raise HTTPException(500, f"Inference error: {e}")

static_dir = os.path.join(os.path.dirname(__file__), "static")
if os.path.exists(static_dir):
    app.mount("/static", StaticFiles(directory=static_dir), name="static")

if __name__ == "__main__":
    import uvicorn; uvicorn.run("app.main:app", host="0.0.0.0", port=8000, reload=True)
