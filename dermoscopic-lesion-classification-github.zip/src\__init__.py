# Dermoscopic Lesion Classification Package
# Models: SVM Baseline, EfficientNet-B3, RNN-LSTM (BiLSTM)
