# ponytail: minimal severity grading system
# Class details mapping
LESION_CLASSES = {
    'akiec': {
        'name': 'Actinic Keratosis / Intraepithelial Carcinoma',
        'risk_level': 'MODERATE RISK',
        'type': 'Pre-cancerous / Carcinoma in situ',
        'description': 'Rough, scaly patches on sun-exposed skin. May progress to squamous cell carcinoma if untreated.'
    },
    'bcc': {
        'name': 'Basal Cell Carcinoma',
        'risk_level': 'MODERATE RISK',
        'type': 'Malignant Skin Cancer',
        'description': 'Common non-melanoma skin cancer. Usually slow-growing but requires medical removal.'
    },
    'bkl': {
        'name': 'Benign Keratosis-like Lesion',
        'risk_level': 'LOW RISK',
        'type': 'Benign Growth',
        'description': 'Includes seborrheic keratoses and solar lentigines. Harmless skin growths common with aging.'
    },
    'df': {
        'name': 'Dermatofibroma',
        'risk_level': 'LOW RISK',
        'type': 'Benign Growth',
        'description': 'Firm, harmless skin nodule often occurring on lower legs.'
    },
    'mel': {
        'name': 'Melanoma',
        'risk_level': 'HIGH RISK',
        'type': 'Aggressive Malignant Cancer',
        'description': 'Serious form of skin cancer arising from melanocytes. Requires urgent dermatological evaluation.'
    },
    'nv': {
        'name': 'Melanocytic Nevi',
        'risk_level': 'LOW RISK',
        'type': 'Benign Mole',
        'description': 'Common benign mole formed by clusters of melanocytes. Requires regular monitoring.'
    },
    'vasc': {
        'name': 'Vascular Lesion',
        'risk_level': 'LOW RISK',
        'type': 'Benign Vascular Growth',
        'description': 'Blood vessel skin lesions including cherry angiomas and pyogenic granulomas.'
    }
}

CLASS_LIST = ['akiec', 'bcc', 'bkl', 'df', 'mel', 'nv', 'vasc']

def get_severity_grade(pred_class: str, confidence: float) -> dict:
    """
    Evaluates clinical severity risk level and action recommendation based on prediction and confidence.
    """
    pred_class_clean = pred_class.lower().strip()
    class_info = LESION_CLASSES.get(pred_class_clean, {
        'name': pred_class,
        'risk_level': 'UNKNOWN',
        'type': 'Unclassified',
        'description': 'Unknown skin condition.'
    })
    
    # Low confidence override (< 50%) -> Specialist review
    if confidence < 0.50:
        return {
            'risk_level': 'HIGH RISK',
            'badge_color': 'red',
            'summary': 'Low Model Confidence (< 50%)',
            'recommendation': f"Model predicted {class_info['name']} with low confidence ({confidence*100:.1f}%). Specialist dermatologist review recommended.",
            'safety_net_triggered': True
        }
    
    if pred_class_clean == 'mel':
        if confidence >= 0.70:
            return {
                'risk_level': 'HIGH RISK',
                'badge_color': 'red',
                'summary': f"Melanoma Detected ({confidence*100:.1f}% confidence)",
                'recommendation': 'Melanoma suspected with high model confidence. Urgent referral to a specialist dermatologist is strongly advised.',
                'safety_net_triggered': True
            }
        else:
            return {
                'risk_level': 'HIGH RISK',
                'badge_color': 'red',
                'summary': f"Possible Melanoma ({confidence*100:.1f}% confidence)",
                'recommendation': 'Possible melanoma detected. Urgent specialist review recommended for biopsy and histopathological verification.',
                'safety_net_triggered': True
            }
    elif pred_class_clean in ['bcc', 'akiec']:
        return {
            'risk_level': 'MODERATE RISK',
            'badge_color': 'amber',
            'summary': f"{class_info['name']} ({confidence*100:.1f}% confidence)",
            'recommendation': f"{class_info['name']} detected. Dermatologist consultation recommended for treatment planning.",
            'safety_net_triggered': False
        }
    else: # nv, bkl, df, vasc
        if confidence >= 0.70:
            return {
                'risk_level': 'LOW RISK',
                'badge_color': 'green',
                'summary': f"{class_info['name']} ({confidence*100:.1f}% confidence)",
                'recommendation': f"Likely benign {class_info['name']}. Routine self-monitoring recommended; report changes in size, color, or shape.",
                'safety_net_triggered': False
            }
        else:
            return {
                'risk_level': 'LOW RISK',
                'badge_color': 'green',
                'summary': f"Likely {class_info['name']} ({confidence*100:.1f}% confidence)",
                'recommendation': f"Appears to be {class_info['name']}. Monitor lesion periodically for visual changes.",
                'safety_net_triggered': False
            }
