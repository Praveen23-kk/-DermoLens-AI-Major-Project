document.addEventListener('DOMContentLoaded', () => {
    // --- 1. Navigation Tabs Switcher ---
    const tabButtons = document.querySelectorAll('.tab-btn');
    const tabViews = document.querySelectorAll('.tab-view');

    tabButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            const targetTab = btn.getAttribute('data-tab');
            tabButtons.forEach(b => b.classList.remove('active'));
            tabViews.forEach(v => v.classList.remove('active'));

            btn.classList.add('active');
            const targetView = document.getElementById(targetTab);
            if (targetView) targetView.classList.add('active');
        });
    });

    // --- 2. DOM Elements ---
    const smoothDropzone = document.getElementById('smooth-dropzone');
    const filePicker = document.getElementById('file-picker');
    const dropPrompt = document.getElementById('drop-prompt');
    const previewBox = document.getElementById('preview-box');
    const previewImgSrc = document.getElementById('preview-img-src');
    const btnResetImg = document.getElementById('btn-reset-img');
    const btnRunInference = document.getElementById('btn-run-inference');
    const sampleChips = document.querySelectorAll('.sample-chip');

    const outputEmpty = document.getElementById('output-empty');
    const outputLoading = document.getElementById('output-loading');
    const outputResults = document.getElementById('output-results');

    const resClassName = document.getElementById('res-class-name');
    const resRiskTag = document.getElementById('res-risk-tag');
    const resConfidencePct = document.getElementById('res-confidence-pct');
    const resConfidenceFill = document.getElementById('res-confidence-fill');
    const resClinicalAlert = document.getElementById('res-clinical-alert');
    const resClinicalText = document.getElementById('res-clinical-text');

    const visOrigImg = document.getElementById('vis-orig-img');
    const visOverlayImg = document.getElementById('vis-overlay-img');
    const visSplitOrig = document.getElementById('vis-split-orig');
    const visSplitHeatmap = document.getElementById('vis-split-heatmap');
    const resBlendSlider = document.getElementById('res-blend-slider');
    const blendSliderGroup = document.getElementById('blend-slider-group');

    const singleCanvasBox = document.getElementById('single-canvas-box');
    const splitCanvasBox = document.getElementById('split-canvas-box');
    const viewModeBtns = document.querySelectorAll('.view-mode-btn');

    const resMatrixList = document.getElementById('res-matrix-list');
    const btnToggleJson = document.getElementById('btn-toggle-json');
    const jsonDrawer = document.getElementById('json-drawer');
    const rawJsonOutput = document.getElementById('raw-json-output');

    let selectedFile = null;
    let currentInferenceData = null;

    // --- 3. Dropzone & File Handling ---
    ['dragenter', 'dragover'].forEach(evt => {
        smoothDropzone.addEventListener(evt, (e) => {
            e.preventDefault();
            e.stopPropagation();
            smoothDropzone.classList.add('dragover');
        });
    });

    ['dragleave', 'drop'].forEach(evt => {
        smoothDropzone.addEventListener(evt, (e) => {
            e.preventDefault();
            e.stopPropagation();
            smoothDropzone.classList.remove('dragover');
        });
    });

    smoothDropzone.addEventListener('drop', (e) => {
        const files = e.dataTransfer.files;
        if (files.length > 0) processFile(files[0]);
    });

    smoothDropzone.addEventListener('click', (e) => {
        if (e.target.closest('#btn-reset-img')) return;
        if (!selectedFile) filePicker.click();
    });

    filePicker.addEventListener('change', (e) => {
        if (e.target.files.length > 0) processFile(e.target.files[0]);
    });

    btnResetImg.addEventListener('click', (e) => {
        e.stopPropagation();
        clearFileSelection();
    });

    function processFile(file) {
        if (!file.type.startsWith('image/')) {
            alert('Please select a valid image file (JPEG, PNG, WEBP).');
            return;
        }
        selectedFile = file;
        const reader = new FileReader();
        reader.onload = (e) => {
            previewImgSrc.src = e.target.result;
            dropPrompt.classList.add('utility-hidden');
            previewBox.classList.remove('utility-hidden');
            btnRunInference.disabled = false;
        };
        reader.readAsDataURL(file);
    }

    function clearFileSelection() {
        selectedFile = null;
        filePicker.value = '';
        previewImgSrc.src = '';
        previewBox.classList.add('utility-hidden');
        dropPrompt.classList.remove('utility-hidden');
        btnRunInference.disabled = true;
    }

    // --- 4. Quick Sample Chips ---
    sampleChips.forEach(chip => {
        chip.addEventListener('click', async () => {
            const fileName = chip.getAttribute('data-sample');
            try {
                const res = await fetch(`/samples/${fileName}`);
                if (!res.ok) throw new Error('Sample not found');
                const blob = await res.blob();
                const file = new File([blob], fileName, { type: blob.type || 'image/jpeg' });
                processFile(file);
            } catch (err) {
                console.error(err);
                alert('Could not load sample image.');
            }
        });
    });

    // --- 5. Visualizer Mode Switching (Blend, Split, Heatmap) ---
    viewModeBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const mode = btn.getAttribute('data-mode');
            viewModeBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');

            if (mode === 'blend') {
                splitCanvasBox.classList.add('utility-hidden');
                singleCanvasBox.classList.remove('utility-hidden');
                blendSliderGroup.classList.remove('utility-hidden');
                visOverlayImg.style.opacity = resBlendSlider.value / 100;
            } else if (mode === 'split') {
                singleCanvasBox.classList.add('utility-hidden');
                blendSliderGroup.classList.add('utility-hidden');
                splitCanvasBox.classList.remove('utility-hidden');
            } else if (mode === 'heatmap') {
                splitCanvasBox.classList.add('utility-hidden');
                singleCanvasBox.classList.remove('utility-hidden');
                blendSliderGroup.classList.add('utility-hidden');
                visOverlayImg.style.opacity = 1.0;
            }
        });
    });

    resBlendSlider.addEventListener('input', (e) => {
        visOverlayImg.style.opacity = e.target.value / 100;
    });

    // --- 6. JSON Drawer Toggle ---
    btnToggleJson.addEventListener('click', () => {
        jsonDrawer.classList.toggle('utility-hidden');
    });

    // --- 7. Run AI Diagnosis ---
    btnRunInference.addEventListener('click', async () => {
        if (!selectedFile) return;

        outputEmpty.classList.add('utility-hidden');
        outputResults.classList.add('utility-hidden');
        outputLoading.classList.remove('utility-hidden');

        const formData = new FormData();
        formData.append('file', selectedFile);

        try {
            const response = await fetch('/api/predict', {
                method: 'POST',
                body: formData
            });

            if (!response.ok) {
                const errJson = await response.json();
                throw new Error(errJson.detail || 'Prediction failed');
            }

            currentInferenceData = await response.json();
            renderInferenceResults(currentInferenceData);
        } catch (err) {
            console.error('Inference error:', err);
            alert(`Error: ${err.message}`);
            outputLoading.classList.add('utility-hidden');
            outputResults.classList.add('utility-hidden');
            outputEmpty.classList.remove('utility-hidden');
        }
    });

    function renderInferenceResults(data) {
        outputLoading.classList.add('utility-hidden');
        outputEmpty.classList.add('utility-hidden');
        outputResults.classList.remove('utility-hidden');

        const { prediction, severity, class_probabilities, visualizations } = data;

        // Top prediction & confidence
        resClassName.textContent = prediction.name;
        resConfidencePct.textContent = `${prediction.confidence_percentage}%`;
        resConfidenceFill.style.width = `${prediction.confidence_percentage}%`;

        // Risk tag
        resRiskTag.textContent = severity.risk_level;
        resRiskTag.className = 'risk-tag';
        if (severity.badge_color === 'red') resRiskTag.classList.add('red');
        else if (severity.badge_color === 'amber') resRiskTag.classList.add('amber');
        else resRiskTag.classList.add('green');

        // Clinical alert
        resClinicalText.textContent = severity.recommendation;
        resClinicalAlert.className = 'clinical-alert';
        if (severity.badge_color === 'red') resClinicalAlert.classList.add('red-alert');
        else if (severity.badge_color === 'amber') resClinicalAlert.classList.add('amber-alert');
        else resClinicalAlert.classList.add('green-alert');

        // Visualizer images
        visOrigImg.src = visualizations.original_b64;
        visOverlayImg.src = visualizations.gradcam_overlay_b64;
        visSplitOrig.src = visualizations.original_b64;
        visSplitHeatmap.src = visualizations.gradcam_overlay_b64;

        // Reset to default blend mode
        resBlendSlider.value = 50;
        visOverlayImg.style.opacity = 0.5;

        // Probability bars
        resMatrixList.innerHTML = '';
        class_probabilities.forEach(item => {
            const isTop = item.class_code === prediction.class_code;
            const row = document.createElement('div');
            row.className = 'matrix-row';
            row.innerHTML = `
                <div class="matrix-row-meta">
                    <span class="matrix-row-name">${isTop ? '<strong>' : ''}${item.name} (${item.class_code.toUpperCase()})${isTop ? '</strong>' : ''}</span>
                    <span class="matrix-row-pct">${item.percentage}%</span>
                </div>
                <div class="matrix-bar-track">
                    <div class="matrix-bar-fill ${isTop ? 'highlight' : ''}" style="width: ${item.percentage}%"></div>
                </div>
            `;
            resMatrixList.appendChild(row);
        });

        // JSON payload
        const payloadToDisplay = {
            prediction: prediction,
            severity: severity,
            class_probabilities: class_probabilities,
            model_status: data.model_status
        };
        rawJsonOutput.textContent = JSON.stringify(payloadToDisplay, null, 2);
    }
});
