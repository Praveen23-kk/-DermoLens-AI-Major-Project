# ponytail: comparison plot generator
# Usage: python -m src.compare_models
import os, json, logging
import numpy as np

logger = logging.getLogger(__name__)

try:
    import matplotlib; matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    HAS_MPL = True
except ImportError:
    HAS_MPL = False

COLORS = {'SVM_Baseline': '#FF6B6B', 'SVM_baseline': '#FF6B6B', 'EfficientNet_B3': '#4ECDC4', 'RNN_LSTM': '#A78BFA'}
LABELS = {'SVM_Baseline': 'SVM Baseline', 'SVM_baseline': 'SVM Baseline', 'EfficientNet_B3': 'EfficientNet-B3', 'RNN_LSTM': 'RNN-LSTM'}
STYLE = {'figure.facecolor':'#0F172A','axes.facecolor':'#1E293B','axes.edgecolor':'#334155','axes.labelcolor':'#E2E8F0','text.color':'#E2E8F0','xtick.color':'#94A3B8','ytick.color':'#94A3B8','grid.color':'#334155','grid.alpha':0.5,'font.size':11,'legend.facecolor':'#1E293B','legend.edgecolor':'#334155'}

def _bar(metrics, key, title, ylabel, path, ylim=100, fmt='.1f', suf='%'):
    if not HAS_MPL: return
    plt.rcParams.update(STYLE); fig, ax = plt.subplots(figsize=(10,6))
    models = list(metrics.keys()); vals = [metrics[m].get(key,0) for m in models]
    bars = ax.bar([LABELS.get(m,m) for m in models], vals, color=[COLORS.get(m,'#64748B') for m in models], width=0.5, edgecolor='white', linewidth=0.5, zorder=3)
    for b, v in zip(bars, vals): ax.text(b.get_x()+b.get_width()/2., b.get_height()+ylim*0.005, f'{v:{fmt}}{suf}', ha='center', va='bottom', fontweight='bold', fontsize=13, color='white')
    ax.set_ylabel(ylabel, fontweight='bold'); ax.set_title(title, fontsize=16, fontweight='bold', pad=15); ax.set_ylim(0, ylim); ax.grid(axis='y', linestyle='--', alpha=0.3, zorder=0)
    plt.tight_layout(); plt.savefig(path, dpi=200, bbox_inches='tight'); plt.close()

def plot_combined(metrics, save_dir):
    if not HAS_MPL: return
    plt.rcParams.update(STYLE); fig, axes = plt.subplots(2,2, figsize=(16,12))
    models = list(metrics.keys()); labels = [LABELS.get(m,m) for m in models]; colors = [COLORS.get(m,'#64748B') for m in models]
    for (ax,key,title,ylim,fmt,suf,bc) in [(axes[0,0],'accuracy','Test Accuracy (%)',100,'.1f','%',colors),(axes[0,1],'macro_f1','Macro F1 Score',1.0,'.3f','',colors),(axes[1,0],'melanoma_recall','Melanoma Recall (%)',105,'.1f','%',['#F97316']*len(models)),(axes[1,1],'vasc_recall','Vascular Recall (%)',105,'.1f','%',['#06B6D4']*len(models))]:
        vals = [metrics[m].get(key,0) for m in models]
        bars = ax.bar(labels, vals, color=bc, width=0.5, edgecolor='white', linewidth=0.5, zorder=3)
        for b,v in zip(bars,vals): ax.text(b.get_x()+b.get_width()/2., b.get_height()+ylim*0.005, f'{v:{fmt}}{suf}', ha='center', va='bottom', fontweight='bold', fontsize=11, color='white')
        ax.set_title(title, fontsize=14, fontweight='bold'); ax.set_ylim(0, ylim); ax.grid(axis='y', linestyle='--', alpha=0.3, zorder=0)
    fig.suptitle('DermoLens AI — Model Comparison Dashboard', fontsize=18, fontweight='bold', y=0.98)
    plt.tight_layout(rect=[0,0,1,0.95]); plt.savefig(os.path.join(save_dir,'model_comparison_dashboard.png'), dpi=200, bbox_inches='tight'); plt.close()

def generate_all_comparison_plots(metrics, save_dir):
    if not HAS_MPL: return
    os.makedirs(save_dir, exist_ok=True)
    _bar(metrics,'accuracy','Model Accuracy Comparison','Accuracy (%)',os.path.join(save_dir,'accuracy_comparison.png'))
    _bar(metrics,'macro_f1','Macro F1 Comparison','Macro F1',os.path.join(save_dir,'f1_comparison.png'),ylim=1.0,fmt='.3f',suf='')
    # grouped recall
    plt.rcParams.update(STYLE); fig, ax = plt.subplots(figsize=(10,6))
    models = list(metrics.keys()); x = np.arange(len(models))
    ax.bar(x-0.15,[metrics[m].get('melanoma_recall',0) for m in models],0.3,label='Melanoma',color='#F97316',edgecolor='white',linewidth=0.5,zorder=3)
    ax.bar(x+0.15,[metrics[m].get('vasc_recall',0) for m in models],0.3,label='Vascular',color='#06B6D4',edgecolor='white',linewidth=0.5,zorder=3)
    ax.set_xticks(x); ax.set_xticklabels([LABELS.get(m,m) for m in models]); ax.set_ylim(0,105)
    ax.set_title('Critical Class Recall',fontsize=16,fontweight='bold',pad=15); ax.legend(); ax.grid(axis='y',linestyle='--',alpha=0.3,zorder=0)
    plt.tight_layout(); plt.savefig(os.path.join(save_dir,'critical_recall_comparison.png'),dpi=200,bbox_inches='tight'); plt.close()
    plot_combined(metrics, save_dir)
    logger.info(f"Plots saved to {save_dir}")

def generate_plots_from_json(json_path=None, save_dir=None):
    root = os.path.dirname(os.path.dirname(__file__))
    json_path = json_path or os.path.join(root,'docs','model_comparison.json')
    save_dir = save_dir or os.path.join(root,'docs')
    if not os.path.exists(json_path): return
    with open(json_path) as f: generate_all_comparison_plots(json.load(f), save_dir)

if __name__ == '__main__':
    generate_plots_from_json()
