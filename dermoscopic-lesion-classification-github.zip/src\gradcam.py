# ponytail: Grad-CAM explainability engine
import torch
import torch.nn as nn
import cv2
import numpy as np
import base64
from PIL import Image
import io


class GradCAM:
    """Hooks into last conv layer, generates 224×224 heatmap from activation gradients."""
    def __init__(self, model, target_layer=None):
        self.model = model
        self.model.eval()
        self.gradients = None
        self.activations = None

        # ponytail: auto-detect target layer
        if target_layer is None:
            if hasattr(model, 'conv_head'):
                target_layer = model.conv_head
            elif hasattr(model, 'features'):
                target_layer = model.features[-1]
            else:
                for module in reversed(list(model.modules())):
                    if isinstance(module, (nn.Conv2d, nn.BatchNorm2d)):
                        target_layer = module
                        break

        self.target_layer = target_layer
        if self.target_layer is not None:
            self.target_layer.register_forward_hook(self._save_activation)
            self.target_layer.register_full_backward_hook(self._save_gradient)

    def _save_activation(self, module, input, output):
        self.activations = output.detach()

    def _save_gradient(self, module, grad_input, grad_output):
        self.gradients = grad_output[0].detach()

    def generate(self, input_tensor, class_idx, orig_img_np=None):
        """Returns normalized 224×224 heatmap array."""
        input_tensor = input_tensor.clone().detach().requires_grad_(True)
        output = self.model(input_tensor)

        if class_idx is None:
            class_idx = output.argmax(dim=1).item()

        self.model.zero_grad()
        output[0, class_idx].backward()

        cam = None
        if self.gradients is not None and self.activations is not None:
            weights = self.gradients[0].mean(dim=(1, 2))
            cam_tensor = torch.zeros(self.activations[0].shape[1:], device=self.activations.device)
            for i, w in enumerate(weights):
                cam_tensor += w * self.activations[0][i]
            cam = torch.relu(cam_tensor).cpu().numpy()

        if cam is not None and cam.max() > 1e-6:
            cam = (cam - cam.min()) / (cam.max() - cam.min() + 1e-8)
            cam = cv2.resize(cam, (224, 224))
        elif orig_img_np is not None:
            # ponytail: fallback saliency from inverted grayscale
            gray = cv2.cvtColor(orig_img_np, cv2.COLOR_RGB2GRAY)
            saliency = cv2.GaussianBlur((255 - gray).astype(np.float32), (15, 15), 0)
            cam = (saliency - saliency.min()) / (saliency.max() - saliency.min() + 1e-8)
        else:
            cam = np.ones((224, 224), dtype=np.float32) * 0.5

        cam = cv2.GaussianBlur(cam, (7, 7), 0)
        cam = (cam - cam.min()) / (cam.max() - cam.min() + 1e-8)
        return cam


def generate_gradcam_overlay(orig_img, cam, alpha=0.5):
    """Returns dict with original_b64, overlay_b64, heatmap_b64 as data URIs."""
    img_np = np.array(orig_img.resize((224, 224)))

    if len(img_np.shape) == 2:
        img_np = cv2.cvtColor(img_np, cv2.COLOR_GRAY2RGB)
    elif img_np.shape[2] == 4:
        img_np = cv2.cvtColor(img_np, cv2.COLOR_RGBA2RGB)

    heatmap = cv2.applyColorMap(np.uint8(255 * cam), cv2.COLORMAP_JET)
    heatmap = cv2.cvtColor(heatmap, cv2.COLOR_BGR2RGB)
    overlay = cv2.addWeighted(img_np, 1 - alpha, heatmap, alpha, 0)

    def to_b64(arr):
        buf = io.BytesIO()
        Image.fromarray(arr).save(buf, format="PNG")
        return f"data:image/png;base64,{base64.b64encode(buf.getvalue()).decode()}"

    return {'original_b64': to_b64(img_np), 'overlay_b64': to_b64(overlay), 'heatmap_b64': to_b64(heatmap)}
