# ponytail: unified training pipeline — SVM, EfficientNet-B3, RNN-LSTM
# Usage: python -m src.train --model all --data_dir ./data/HAM10000 --epochs 25
import os
import sys
import json
import time
import pickle
import logging
import argparse
import numpy as np
from pathlib import Path
from datetime import datetime

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, WeightedRandomSampler
from torchvision import datasets, transforms
from sklearn.metrics import accuracy_score, f1_score, classification_report, confusion_matrix

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))
from src.severity import CLASS_LIST

logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(message)s', datefmt='%H:%M:%S')
logger = logging.getLogger('DermoTrainer')

NUM_CLASSES = 7
IMG_SIZE = 224
MODELS_DIR = PROJECT_ROOT / 'models'
DOCS_DIR = PROJECT_ROOT / 'docs'

train_transform = transforms.Compose([
    transforms.Resize((IMG_SIZE, IMG_SIZE)),
    transforms.RandomHorizontalFlip(), transforms.RandomVerticalFlip(),
    transforms.RandomRotation(20),
    transforms.ColorJitter(brightness=0.2, contrast=0.2, saturation=0.2, hue=0.05),
    transforms.RandomAffine(degrees=0, translate=(0.1, 0.1)),
    transforms.ToTensor(),
    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
])

val_transform = transforms.Compose([
    transforms.Resize((IMG_SIZE, IMG_SIZE)),
    transforms.ToTensor(),
    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
])


def create_data_loaders(data_dir, batch_size=32):
    """Create train/val/test loaders from ImageFolder structure (data_dir/train, /val, /test)."""
    loaders = {}
    for split, tfm, shuffle in [('train', train_transform, False), ('val', val_transform, False), ('test', val_transform, False)]:
        split_dir = os.path.join(data_dir, split)
        if not os.path.exists(split_dir):
            continue
        ds = datasets.ImageFolder(split_dir, transform=tfm)
        if split == 'train':
            counts = np.bincount([s[1] for s in ds.samples], minlength=NUM_CLASSES)
            weights = 1.0 / (counts + 1e-6)
            sampler = WeightedRandomSampler([weights[l] for _, l in ds.samples], len(ds), replacement=True)
            loaders[split] = DataLoader(ds, batch_size=batch_size, sampler=sampler, num_workers=2, pin_memory=True, drop_last=True)
            logger.info(f"Train: {len(ds)} images | {dict(zip(CLASS_LIST, counts.tolist()))}")
        else:
            loaders[split] = DataLoader(ds, batch_size=batch_size, shuffle=False, num_workers=2, pin_memory=True)
            logger.info(f"{split.capitalize()}: {len(ds)} images")
    return loaders


class TrainingEngine:
    """Trains any PyTorch model with early stopping, cosine LR, and gradient clipping."""
    def __init__(self, model, name, device, save_dir):
        self.model = model.to(device)
        self.name = name
        self.device = device
        self.save_dir = Path(save_dir)
        self.save_dir.mkdir(parents=True, exist_ok=True)
        self.history = {'train_loss': [], 'val_loss': [], 'train_acc': [], 'val_acc': []}
        self.best_val_acc = 0.0

    def train(self, train_loader, val_loader, epochs=25, lr=1e-3):
        criterion = nn.CrossEntropyLoss(label_smoothing=0.1)
        optimizer = optim.AdamW(filter(lambda p: p.requires_grad, self.model.parameters()), lr=lr, weight_decay=1e-4)
        scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=epochs, eta_min=1e-6)
        patience, patience_counter, best_weights = 7, 0, None

        logger.info(f"Training {self.name} | {epochs} epochs | LR={lr} | {self.device}")

        for epoch in range(1, epochs + 1):
            self.model.train()
            loss_sum, correct, total = 0.0, 0, 0
            for images, labels in train_loader:
                images, labels = images.to(self.device), labels.to(self.device)
                optimizer.zero_grad()
                out = self.model(images)
                loss = criterion(out, labels)
                loss.backward()
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)
                optimizer.step()
                loss_sum += loss.item() * images.size(0)
                correct += (out.argmax(1) == labels).sum().item()
                total += labels.size(0)

            t_loss, t_acc = loss_sum / total, correct / total
            v_loss, v_acc = self._evaluate(val_loader, criterion)
            scheduler.step()

            self.history['train_loss'].append(t_loss)
            self.history['val_loss'].append(v_loss)
            self.history['train_acc'].append(t_acc)
            self.history['val_acc'].append(v_acc)

            logger.info(f"  Epoch {epoch}/{epochs} | Train {t_acc:.4f} | Val {v_acc:.4f} | LR {scheduler.get_last_lr()[0]:.2e}")

            if v_acc > self.best_val_acc:
                self.best_val_acc = v_acc
                best_weights = {k: v.cpu().clone() for k, v in self.model.state_dict().items()}
                patience_counter = 0
            else:
                patience_counter += 1
            if patience_counter >= patience:
                logger.info(f"  Early stopping at epoch {epoch}")
                break

        if best_weights:
            self.model.load_state_dict(best_weights)
        save_path = self.save_dir / f'{self.name.lower()}_best.pth'
        torch.save(self.model.state_dict(), save_path)
        logger.info(f"  Saved {save_path} (best_val_acc={self.best_val_acc:.4f})")
        return self.history

    def _evaluate(self, loader, criterion):
        self.model.eval()
        loss_sum, correct, total = 0.0, 0, 0
        with torch.no_grad():
            for images, labels in loader:
                images, labels = images.to(self.device), labels.to(self.device)
                out = self.model(images)
                loss_sum += criterion(out, labels).item() * images.size(0)
                correct += (out.argmax(1) == labels).sum().item()
                total += labels.size(0)
        return loss_sum / total, correct / total

    def test(self, test_loader):
        """Evaluate on test set, returns metrics dict."""
        self.model.eval()
        all_preds, all_labels = [], []
        with torch.no_grad():
            for images, labels in test_loader:
                images, labels = images.to(self.device), labels.to(self.device)
                all_preds.extend(self.model(images).argmax(1).cpu().numpy())
                all_labels.extend(labels.cpu().numpy())

        y_true, y_pred = np.array(all_labels), np.array(all_preds)
        report = classification_report(y_true, y_pred, target_names=CLASS_LIST, output_dict=True, zero_division=0)

        metrics = {
            'accuracy': round(accuracy_score(y_true, y_pred) * 100, 2),
            'macro_f1': round(f1_score(y_true, y_pred, average='macro', zero_division=0), 4),
            'melanoma_recall': round(report['mel']['recall'] * 100, 1),
            'vasc_recall': round(report['vasc']['recall'] * 100, 1),
            'per_class_recall': {c: round(report[c]['recall'] * 100, 1) for c in CLASS_LIST},
            'confusion_matrix': confusion_matrix(y_true, y_pred).tolist()
        }
        logger.info(f"Test {self.name}: Acc={metrics['accuracy']}% F1={metrics['macro_f1']} MelRecall={metrics['melanoma_recall']}%")
        return metrics


def train_svm(data_dir):
    """Train SVM baseline with HOG features."""
    from sklearn.svm import LinearSVC
    from sklearn.preprocessing import StandardScaler
    from sklearn.pipeline import Pipeline
    import cv2

    def extract_hog(img_path, size=(64, 64)):
        img = cv2.imread(img_path)
        if img is None: return None
        gray = cv2.cvtColor(cv2.resize(img, size), cv2.COLOR_BGR2GRAY)
        hog = cv2.HOGDescriptor(size, (16,16), (8,8), (8,8), 9)
        return hog.compute(gray).flatten()

    def load_features(split_dir):
        features, labels = [], []
        classes = sorted([d for d in os.listdir(split_dir) if os.path.isdir(os.path.join(split_dir, d))])
        class_map = {c: i for i, c in enumerate(classes)}
        for cls, idx in class_map.items():
            for f in os.listdir(os.path.join(split_dir, cls)):
                feat = extract_hog(os.path.join(split_dir, cls, f))
                if feat is not None:
                    features.append(feat); labels.append(idx)
        return np.array(features), np.array(labels), class_map

    train_dir = os.path.join(data_dir, 'train')
    if not os.path.exists(train_dir):
        logger.error(f"Train dir not found: {train_dir}"); return None

    X_train, y_train, class_map = load_features(train_dir)
    logger.info(f"SVM: {X_train.shape[0]} samples, {X_train.shape[1]} features")

    pipe = Pipeline([('scaler', StandardScaler()), ('svm', LinearSVC(C=1.0, max_iter=5000, class_weight='balanced'))])
    pipe.fit(X_train, y_train)

    metrics = {'accuracy': round(accuracy_score(y_train, pipe.predict(X_train)) * 100, 2), 'macro_f1': 0.0}
    test_dir = os.path.join(data_dir, 'test')
    if os.path.exists(test_dir):
        X_test, y_test, _ = load_features(test_dir)
        y_pred = pipe.predict(X_test)
        report = classification_report(y_test, y_pred, target_names=CLASS_LIST, output_dict=True, zero_division=0)
        metrics = {
            'accuracy': round(accuracy_score(y_test, y_pred) * 100, 2),
            'macro_f1': round(f1_score(y_test, y_pred, average='macro', zero_division=0), 4),
            'melanoma_recall': round(report['mel']['recall'] * 100, 1),
            'vasc_recall': round(report['vasc']['recall'] * 100, 1),
        }

    with open(MODELS_DIR / 'svm_pipeline.pkl', 'wb') as f:
        pickle.dump({'model': pipe, 'class_map': class_map, 'class_list': CLASS_LIST, 'metrics': metrics, 'trained_at': datetime.now().isoformat()}, f)
    logger.info(f"SVM saved | Acc={metrics['accuracy']}%")
    return metrics


def build_efficientnet():
    try:
        import timm
        return timm.create_model('efficientnet_b3', pretrained=True, num_classes=NUM_CLASSES)
    except Exception:
        from torchvision.models import efficientnet_b3, EfficientNet_B3_Weights
        m = efficientnet_b3(weights=EfficientNet_B3_Weights.DEFAULT)
        m.classifier[1] = nn.Linear(m.classifier[1].in_features, NUM_CLASSES)
        return m


def build_rnn():
    from src.rnn_model import DermoLSTMClassifier
    m = DermoLSTMClassifier(num_classes=NUM_CLASSES)
    m.freeze_cnn()
    return m


def export_model_pickle(model, name, metrics, class_list, save_dir):
    """Save deployment pickle with weights + preprocessing config."""
    path = Path(save_dir) / f'{name.lower().replace(" ","_").replace("-","_")}_deployment.pkl'
    bundle = {
        'model_name': name, 'model_state_dict': {k: v.cpu() for k, v in model.state_dict().items()},
        'num_classes': NUM_CLASSES, 'class_list': class_list, 'img_size': IMG_SIZE,
        'normalize_mean': [0.485, 0.456, 0.406], 'normalize_std': [0.229, 0.224, 0.225],
        'metrics': metrics, 'exported_at': datetime.now().isoformat(), 'pytorch_version': torch.__version__
    }
    with open(path, 'wb') as f:
        pickle.dump(bundle, f)
    logger.info(f"Pickle: {path} ({os.path.getsize(path)/1024/1024:.1f} MB)")


def main():
    parser = argparse.ArgumentParser(description='DermoLens Training')
    parser.add_argument('--model', default='all', choices=['svm', 'efficientnet', 'rnn', 'all'])
    parser.add_argument('--data_dir', default='./data/HAM10000')
    parser.add_argument('--epochs', type=int, default=25)
    parser.add_argument('--batch_size', type=int, default=32)
    parser.add_argument('--lr', type=float, default=1e-3)
    parser.add_argument('--device', default=None)
    args = parser.parse_args()

    device = args.device or ('cuda' if torch.cuda.is_available() else 'cpu')
    MODELS_DIR.mkdir(parents=True, exist_ok=True)
    DOCS_DIR.mkdir(parents=True, exist_ok=True)

    all_metrics = {}
    start = time.time()
    logger.info(f"DermoLens Training | model={args.model} | device={device} | epochs={args.epochs}")

    loaders = create_data_loaders(args.data_dir, args.batch_size)

    if args.model in ('svm', 'all'):
        try:
            m = train_svm(args.data_dir)
            if m: all_metrics['SVM_Baseline'] = m
        except Exception as e:
            logger.error(f"SVM failed: {e}")

    if args.model in ('efficientnet', 'all') and 'train' in loaders:
        try:
            model = build_efficientnet()
            engine = TrainingEngine(model, 'EfficientNet_B3', device, MODELS_DIR)
            engine.train(loaders['train'], loaders.get('val', loaders['train']), epochs=args.epochs, lr=args.lr)
            if 'test' in loaders:
                metrics = engine.test(loaders['test'])
                all_metrics['EfficientNet_B3'] = metrics
                export_model_pickle(model, 'EfficientNet_B3', metrics, CLASS_LIST, MODELS_DIR)
        except Exception as e:
            logger.error(f"EfficientNet failed: {e}")

    if args.model in ('rnn', 'all') and 'train' in loaders:
        try:
            model = build_rnn()
            engine = TrainingEngine(model, 'RNN_LSTM', device, MODELS_DIR)
            engine.train(loaders['train'], loaders.get('val', loaders['train']), epochs=max(args.epochs//2, 5), lr=args.lr)
            model.unfreeze_cnn()
            engine.train(loaders['train'], loaders.get('val', loaders['train']), epochs=max(args.epochs//2, 5), lr=args.lr*0.1)
            if 'test' in loaders:
                metrics = engine.test(loaders['test'])
                all_metrics['RNN_LSTM'] = metrics
                export_model_pickle(model, 'RNN_LSTM', metrics, CLASS_LIST, MODELS_DIR)
        except Exception as e:
            logger.error(f"RNN failed: {e}")

    if all_metrics:
        comp_path = DOCS_DIR / 'model_comparison.json'
        existing = json.load(open(comp_path)) if comp_path.exists() else {}
        existing.update(all_metrics)
        json.dump(existing, open(comp_path, 'w'), indent=4)
        try:
            from src.compare_models import generate_all_comparison_plots
            generate_all_comparison_plots(existing, str(DOCS_DIR))
        except Exception as e:
            logger.warning(f"Plot generation failed: {e}")

    logger.info(f"Done in {(time.time()-start)/60:.1f} min | {json.dumps(all_metrics, indent=2)}")


if __name__ == '__main__':
    main()
