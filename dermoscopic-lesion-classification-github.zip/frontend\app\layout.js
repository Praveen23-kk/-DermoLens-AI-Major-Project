import { Inter } from "next/font/google";
import "./globals.css";

const inter = Inter({ subsets: ["latin"] });

export const metadata = {
  title: "DermoLens AI | EfficientNet-B3 Dermoscopic Diagnostic Control Plane",
  description: "AI-powered dermoscopic lesion classification, explainable Grad-CAM visual heatmaps, and clinical severity risk assessment.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en" className="dark h-full">
      <body className={`${inter.className} min-h-screen bg-slate-950 text-slate-100 flex flex-col antialiased selection:bg-cyan-500 selection:text-white`}>
        {children}
      </body>
    </html>
  );
}
