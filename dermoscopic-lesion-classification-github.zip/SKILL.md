# Dermoscopic Lesion Classification & Agentic Skills

See [SKILL.md](./SKILL.md) for full Agentic Skill Specification, frontmatter triggers, architecture map, API contracts, and clinical triage rules.

---

## ✂️ Ponytail Efficiency & Minimalism Skill (`DietrichGebert/ponytail`)

This project strictly adheres to the **Ponytail Necessity Hierarchy** to eliminate over-engineering, excess LOC, and unnecessary code bloat while preserving 100% security, trust-boundary safety, and clinical correctness.

### The Decision Ladder
Before writing or modifying code, evaluate each step in order and stop at the first applicable solution:

1. **YAGNI (You Ain't Gonna Need It):** Does this feature/logic strictly need to exist right now? If not, skip it completely.
2. **Reuse:** Does a solution already exist in the existing codebase? If so, reuse it.
3. **Standard Library:** Can Python standard libraries or built-in DOM APIs solve this natively?
4. **Native Platform:** Can browser/OS native features (e.g. `<input type="date">`, CSS Grid/Flexbox) accomplish this without external code?
5. **Existing Dependencies:** Is there a library already listed in `requirements.txt` or `package.json` that handles this?
6. **One-Liners:** Can the feature be written cleanly in a single line?
7. **Minimum Viable Code:** Write the absolute minimum LOC required—zero fluff, zero speculative abstractions.

> Any shortcuts or pragmatic minimal implementations should be marked with `// ponytail:` (or `# ponytail:`) for future maintainers.

