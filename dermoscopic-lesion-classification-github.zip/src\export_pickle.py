# ponytail: pickle export — serialize trained models for deployment
# Usage: python -m src.export_pickle --model all
import os, sys, pickle, logging, argparse
from datetime import datetime
from pathlib import Path
import torch, torch.nn as nn

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))
from src.severity import CLASS_LIST, LESION_CLASSES

logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(message)s')
logger = logging.getLogger('PickleExporter')

NUM_CLASSES = 7
IMG_SIZE = 224
MODELS_DIR = PROJECT_ROOT / 'models'

def _build(model_type):
    if model_type == 'efficientnet':
        try:
            import timm; return timm.create_model('efficientnet_b3', pretrained=False, num_classes=NUM_CLASSES)
        except Exception:
            from torchvision.models import efficientnet_b3
            m = efficientnet_b3(weights=None); m.classifier[1] = nn.Linear(m.classifier[1].in_features, NUM_CLASSES); return m
    else:
        from src.rnn_model import DermoLSTMClassifier
        return DermoLSTMClassifier(num_classes=NUM_CLASSES)

DEFAULTS = {'efficientnet': ('EfficientNet-B3', 'best_model.pth'), 'rnn': ('RNN-LSTM', 'rnn_best_model.pth')}

def export_to_pickle(model_type, weights_path=None, output_dir=None):
    """Export model to deployment .pkl file."""
    output_dir = output_dir or str(MODELS_DIR)
    os.makedirs(output_dir, exist_ok=True)

    name, default_file = DEFAULTS[model_type]
    model = _build(model_type)
    target = Path(weights_path) if weights_path else MODELS_DIR / default_file

    loaded = False
    if target.exists():
        try:
            model.load_state_dict(torch.load(str(target), map_location='cpu', weights_only=True))
            loaded = True; logger.info(f"Loaded weights from {target}")
        except Exception as e:
            logger.warning(f"Could not load weights: {e}")
    else:
        logger.warning(f"No weights at {target}")

    model.eval()
    bundle = {
        'model_name': name, 'model_type': model_type,
        'model_state_dict': {k: v.cpu().clone() for k, v in model.state_dict().items()},
        'num_classes': NUM_CLASSES, 'class_list': CLASS_LIST, 'class_info': LESION_CLASSES,
        'img_size': IMG_SIZE, 'preprocessing': {
            'resize': (IMG_SIZE, IMG_SIZE), 'normalize_mean': [0.485,0.456,0.406],
            'normalize_std': [0.229,0.224,0.225], 'input_format': 'RGB'
        },
        'weights_loaded': loaded, 'exported_at': datetime.now().isoformat(), 'pytorch_version': torch.__version__
    }

    out_path = os.path.join(output_dir, f'{name.lower().replace(" ","_").replace("-","_")}_deployment.pkl')
    with open(out_path, 'wb') as f: pickle.dump(bundle, f, protocol=pickle.HIGHEST_PROTOCOL)
    logger.info(f"Exported {name} → {out_path} ({os.path.getsize(out_path)/1024/1024:.1f} MB, weights={'yes' if loaded else 'no'})")
    return out_path

def load_deployment_pickle(pkl_path):
    """Load pickle bundle, returns dict."""
    with open(pkl_path, 'rb') as f: bundle = pickle.load(f)
    logger.info(f"Loaded: {bundle['model_name']} | classes={bundle['num_classes']} | weights={bundle['weights_loaded']}")
    return bundle

def reconstruct_model_from_pickle(pkl_path, device=None):
    """Reconstruct ready-to-use model from pickle. Returns (model, class_list, preprocess_config)."""
    device = device or ('cuda' if torch.cuda.is_available() else 'cpu')
    bundle = load_deployment_pickle(pkl_path)
    model = _build(bundle['model_type'])
    model.load_state_dict(bundle['model_state_dict'])
    model.to(device).eval()
    return model, bundle['class_list'], bundle['preprocessing']

def main():
    p = argparse.ArgumentParser(description='Export models to pickle')
    p.add_argument('--model', required=True, choices=['efficientnet','rnn','all'])
    p.add_argument('--weights', default=None)
    p.add_argument('--output_dir', default=None)
    args = p.parse_args()
    if args.model == 'all':
        export_to_pickle('efficientnet', output_dir=args.output_dir)
        export_to_pickle('rnn', output_dir=args.output_dir)
    else:
        export_to_pickle(args.model, args.weights, args.output_dir)

if __name__ == '__main__':
    main()
