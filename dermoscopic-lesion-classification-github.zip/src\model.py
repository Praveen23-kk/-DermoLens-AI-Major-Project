# ponytail: EfficientNet-B3 model loader + unified model selector
import os
import torch
import torch.nn as nn
import timm
import logging

logger = logging.getLogger(__name__)

NUM_CLASSES = 7
MODEL_NAME = 'efficientnet_b3'


def load_model(weights_path=None, device=None):
    """Load EfficientNet-B3 for 7-class skin lesion classification. Returns (model, status)."""
    if device is None:
        device = 'cuda' if torch.cuda.is_available() else 'cpu'

    logger.info(f"Initializing {MODEL_NAME} on {device}")

    try:
        model = timm.create_model(MODEL_NAME, pretrained=False, num_classes=NUM_CLASSES)
    except Exception:
        from torchvision.models import efficientnet_b3
        model = efficientnet_b3(weights=None)
        model.classifier[1] = nn.Linear(model.classifier[1].in_features, NUM_CLASSES)

    default_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'models', 'best_model.pth')
    target = weights_path if weights_path and os.path.exists(weights_path) else default_path

    status = ""
    if os.path.exists(target):
        try:
            model.load_state_dict(torch.load(target, map_location=device))
            status = f"Loaded checkpoint from {target}"
            logger.info(status)
        except Exception as e:
            status = f"Initialized with random weights ({e})"
            logger.warning(status)
    else:
        status = f"Initialized {MODEL_NAME} (num_classes={NUM_CLASSES}). No weights found."
        logger.info(status)

    model.to(device).eval()
    return model, status


def load_any_model(model_type='efficientnet', weights_path=None, device=None):
    """Unified loader: 'efficientnet' or 'rnn'. Returns (model, status)."""
    if model_type == 'rnn':
        from src.rnn_model import load_rnn_model
        return load_rnn_model(weights_path=weights_path, device=device)
    return load_model(weights_path=weights_path, device=device)
