# 📐 DermoLens AI — System Architecture, Workflow & Component Diagrams

This document contains the official architectural specification, end-to-end operational workflow, and component-level interactive workflow for **DermoLens AI** — a multi-model clinical decision support system for dermoscopic lesion classification and explainable AI.

---

## 1. 🏗 System Architecture Diagram

The system architecture follows a decoupled, modular design consisting of a presentation frontend, a high-throughput FastAPI inference server, an explainable AI (XAI) engine, serialized pickle models, and a unified model training/benchmarking pipeline.

```mermaid
graph TD
    subgraph Presentation Layer ["🖥 Presentation Layer (Frontend Clients)"]
        UI_NEXT["Next.js Control Plane UI<br/>(Glassmorphic / Interactive Grad-CAM)"]
        UI_STATIC["Static HTML/JS Client<br/>(Lightweight Web Interface)"]
    end

    subgraph Gateway Layer ["⚡ API Gateway & Server (FastAPI)"]
        API["FastAPI REST Application<br/>(app/main.py)"]
        EP_HEALTH["GET /health"]
        EP_CLASSES["GET /classes"]
        EP_MODELS["GET /models"]
        EP_PREDICT["POST /predict"]
        
        API --- EP_HEALTH
        API --- EP_CLASSES
        API --- EP_MODELS
        API --- EP_PREDICT
    end

    subgraph Service Layer ["🧠 Diagnostic Service & Inference Engine"]
        PRED_ENG["Inference Pipeline Router<br/>(src/predict.py)"]
        XAI_ENG["Grad-CAM XAI Engine<br/>(src/gradcam.py)"]
        SEV_ENG["Severity Triage Evaluator<br/>(src/severity.py)"]
    end

    subgraph Model Layer ["📦 Model Store & Deployment Pickles (.pkl)"]
        EFF_MODEL["EfficientNet-B3 Pickle<br/>(efficientnet_b3_deployment.pkl)"]
        RNN_MODEL["RNN-LSTM (BiLSTM) Pickle<br/>(rnn_lstm_deployment.pkl)"]
        SVM_MODEL["SVM + HOG Pipeline Pickle<br/>(svm_pipeline.pkl)"]
    end

    subgraph Pipeline Layer ["🏋️ Training & Benchmarking Pipeline"]
        DATA_IN["HAM10000 Dataset<br/>(10,015 Images, 7 Classes)"]
        PREPROC["Data Preprocessing & Augmentation"]
        TRAIN_MGR["Unified Training Manager<br/>(src/train.py)"]
        COMP_MGR["Model Evaluator & Plot Generator<br/>(src/compare_models.py)"]
        EXPORT_MGR["Pickle Export Utility<br/>(src/export_pickle.py)"]
    end

    %% Data Connections
    UI_NEXT -->|HTTP POST /predict| EP_PREDICT
    UI_STATIC -->|HTTP POST /predict| EP_PREDICT
    EP_PREDICT --> PRED_ENG

    PRED_ENG -->|Image Tensor| XAI_ENG
    PRED_ENG -->|Probabilities| SEV_ENG
    PRED_ENG -->|Model Selection| EFF_MODEL
    PRED_ENG -->|Model Selection| RNN_MODEL
    PRED_ENG -->|Model Selection| SVM_MODEL

    DATA_IN --> PREPROC
    PREPROC --> TRAIN_MGR
    TRAIN_MGR -->|Train Weights .pth| EFF_MODEL
    TRAIN_MGR -->|Train Weights .pth| RNN_MODEL
    TRAIN_MGR -->|Train Fit .pkl| SVM_MODEL

    TRAIN_MGR --> COMP_MGR
    COMP_MGR -->|Metrics JSON & PNG Plots| docs/
    TRAIN_MGR --> EXPORT_MGR
    EXPORT_MGR -->|.pkl Packages| Model Layer
```

### Architecture Key Components

1. **Presentation Layer**: Offers a Next.js glassmorphic control plane for clinical visualization, heatmaps, and probability matrices, alongside a zero-dependency static web client.
2. **API Gateway (FastAPI)**: Serves single image inference requests, model metadata, and health probes with low latency.
3. **Inference & Explainability Engine**: Combines feature extraction, probability estimation, Grad-CAM heatmap blending (`conv_head` layer), and 3-tier clinical severity risk assessment (`HIGH`, `MODERATE`, `LOW`).
4. **Model Store**: Self-contained `.pkl` artifacts holding model state dicts, preprocessing configs, class mappings, and metadata for instant production deployment.
5. **Training & Benchmark Suite**: Unified engine to train SVM, EfficientNet-B3, and ResNet18-BiLSTM with automated comparison visualization.

---

## 2. 🔄 End-to-End System Workflow Diagram

This workflow illustrates the full lifecycle of DermoLens AI, from raw dataset processing and multi-model training to serialized export, API initialization, and clinical inference.

```mermaid
flowchart TD
    %% Phase 1: Data Preparation
    subgraph P1 ["Phase 1: Data Ingestion & Preprocessing"]
        A1["Download HAM10000 Dataset<br/>(10,015 Dermoscopic Images)"] --> A2["Structure Folders:<br/>train / val / test (7 Classes)"]
        A2 --> A3["Apply Augmentations:<br/>Random Flip, Rotate, Color Jitter, Normalize"]
    end

    %% Phase 2: Multi-Model Training
    subgraph P2 ["Phase 2: Unified Multi-Model Training"]
        A3 --> B1{"Select Target Model(s)"}
        B1 -->|SVM| B2["Extract HOG Features & Fit LinearSVC"]
        B1 -->|EfficientNet-B3| B3["Fine-tune ImageNet CNN Backbone<br/>(AdamW, Cosine Annealing, Label Smoothing)"]
        B1 -->|RNN-LSTM| B4["ResNet-18 Spatial Features →<br/>Spatial Sequence → BiLSTM + Attention"]
    end

    %% Phase 3: Benchmarking & Deployment
    subgraph P3 ["Phase 3: Benchmarking & Serialization"]
        B2 & B3 & B4 --> C1["Evaluate Model Test Metrics:<br/>Accuracy, Macro F1, Critical Recalls"]
        C1 --> C2["Generate Dashboard Charts & model_comparison.json"]
        C2 --> C3["Export Self-Contained Pickles (.pkl)<br/>(Weights, Configs, Preprocessors)"]
    end

    %% Phase 4: Server Loading & Endpoint Binding
    subgraph P4 ["Phase 4: API Deployment & Initialization"]
        C3 --> D1["Launch FastAPI Server (main.py / uvicorn)"]
        D1 --> D2["Preload EfficientNet / RNN Models into Memory"]
        D2 --> D3["Bind Target Layers for Grad-CAM Visualization"]
    end

    %% Phase 5: Live Inference & Clinical Diagnostics
    subgraph P5 ["Phase 5: Live Diagnostic Workflow"]
        E1["User Uploads Image via UI"] --> E2["Select Diagnostic Model<br/>(EfficientNet / RNN / SVM)"]
        E2 --> E3["Send Request to POST /predict"]
        E3 --> E4["Preprocess Image & Forward Pass"]
        E4 --> E5["Extract Predicted Class & Confidence"]
        E5 --> E6["Generate Grad-CAM Attention Heatmap"]
        E6 --> E7["Compute Clinical Severity Triage Risk"]
        E7 --> E8["Return JSON Response with Base64 Images"]
        E8 --> E9["Render Glassmorphic UI Result Card<br/>(Heatmap Blend Slider, Risk Badge, Probabilities)"]
    end
```

---

## 3. 🧩 Component Workflow Diagram

This detailed sequence diagram depicts the interaction between frontend UI components, API routes, execution modules, XAI generators, and model pickles during an inference request.

```mermaid
sequenceDiagram
    autonumber
    actor Clinician as 🩺 Clinician / User
    participant Dropzone as 📤 Dropzone Component
    participant ControlPanel as 🎛 Model Selector Component
    participant API as ⚡ FastAPI Gateway (/predict)
    participant Preproc as 🖼 Preprocessor Engine
    participant Model as 📦 Serialized Pickle Model
    participant GradCAM as 👁 Grad-CAM XAI Engine
    participant Severity as ⚠️ Severity Triage Matrix
    participant Viewer as 🖥 Result Viewer / Heatmap Canvas

    Clinician->>Dropzone: Drop/Upload Lesion Image (JPEG/PNG)
    Clinician->>ControlPanel: Select Model (e.g., EfficientNet-B3)
    Dropzone->>API: HTTP POST /predict (Multipart Form File + Model Parameter)
    
    activate API
    API->>Preproc: Read Image Bytes & Apply Preprocessing (Resize 224x224, Normalize)
    activate Preproc
    Preproc-->>API: Processed Tensor Batch
    deactivate Preproc

    API->>Model: Load Target Model & Perform Forward Pass
    activate Model
    Model-->>API: Raw Logits / Class Probabilities Matrix
    deactivate Model

    API->>GradCAM: Pass Image Tensor & Target Class Index
    activate GradCAM
    GradCAM->>GradCAM: Register Forward & Backward Hooks on 'conv_head' Layer
    GradCAM->>GradCAM: Compute Gradients & Weighted Feature Activation Sum
    GradCAM->>GradCAM: Apply ReLU & Resize Heatmap to Original Dimensions
    GradCAM->>GradCAM: Blend JET Colormap with Original Image
    GradCAM-->>API: Base64 Overlay Heatmap & Mask
    deactivate GradCAM

    API->>Severity: Assess Class Code (e.g., 'mel', 'bcc', 'nv') & Probabilities
    activate Severity
    Severity->>Severity: Map Class Code to Risk Level (HIGH / MODERATE / LOW)
    Severity-->>API: Clinical Triage Risk Payload + Diagnostic Recommendations
    deactivate Severity

    API-->>Dropzone: Complete Diagnostic JSON Response
    deactivate API

    Dropzone->>Viewer: Update Diagnostics State
    activate Viewer
    Viewer->>Viewer: Animate Confidence Score Counter
    Viewer->>Viewer: Display Clinical Risk Badge (🔴 HIGH / ⚠️ MODERATE / ✅ LOW)
    Viewer->>Viewer: Render Grad-CAM Image with Interactive Opacity Slider
    Viewer->>Viewer: Render Multiclass Distribution Bar Chart (7 Classes)
    Viewer-->>Clinician: Interactive Diagnostic Control View Ready
    deactivate Viewer
```

### Component Interaction Details

- **Dropzone & Model Selector**: Captures input images, allows dynamic model selection between CNN, RNN-LSTM, or traditional SVM baselines.
- **FastAPI /predict Endpoint**: Coordinates asynchronous preprocessing, tensor transformation, model execution, XAI activation, and payload assembly.
- **Grad-CAM Engine**: Dynamically hooks into PyTorch feature layers (`conv_head` for EfficientNet) to generate heatmaps formatted as Base64 data URIs for immediate UI rendering.
- **Severity Evaluator**: Maps probabilities to clinical urgency categories:
  - 🔴 **HIGH RISK**: Melanoma (`mel`)
  - ⚠️ **MODERATE RISK**: Basal Cell Carcinoma (`bcc`), Actinic Keratosis (`akiec`)
  - ✅ **LOW RISK**: Melanocytic Nevi (`nv`), Benign Keratosis (`bkl`), Dermatofibroma (`df`), Vascular Lesions (`vasc`)
- **Result Viewer**: React client-side canvas component providing real-time Grad-CAM overlay opacity blending, probability breakdown bars, and risk alerts.
