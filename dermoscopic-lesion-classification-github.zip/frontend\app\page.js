// ponytail: minimal ultra-smooth diagnostic control plane UI
"use client";

import React, { useState, useEffect, useRef } from "react";
import { 
  Upload, 
  ShieldAlert, 
  CheckCircle2, 
  AlertTriangle, 
  Activity, 
  Layers, 
  Eye, 
  RefreshCw, 
  FileText, 
  ChevronRight, 
  Sparkles,
  Info,
  Sliders,
  Cpu
} from "lucide-react";

const CYCLING_STATUSES = [
  "Initializing PyTorch EfficientNet-B3 model...",
  "Analyzing dermoscopic texture & pigment patterns...",
  "Computing high-dimensional activation tensors...",
  "Generating Grad-CAM explainable AI heatmap...",
  "Finalizing clinical severity risk assessment..."
];

export default function App() {
  // Application State: Simple, clean useState
  const [selectedFile, setSelectedFile] = useState(null);
  const [previewUrl, setPreviewUrl] = useState(null);
  const [loading, setLoading] = useState(false);
  const [statusIndex, setStatusIndex] = useState(0);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);

  // Visualization Controls (Results Screen)
  const [viewMode, setViewMode] = useState("overlay"); // 'original', 'overlay', 'heatmap'
  const [opacity, setOpacity] = useState(0.65);
  const [animatedConfidence, setAnimatedConfidence] = useState(0);

  // Drag and Drop state
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef(null);

  // Status cycling during loading state
  useEffect(() => {
    let interval;
    if (loading) {
      setStatusIndex(0);
      interval = setInterval(() => {
        setStatusIndex((prev) => (prev + 1) % CYCLING_STATUSES.length);
      }, 900);
    }
    return () => clearInterval(interval);
  }, [loading]);

  // Confidence count-up animation on result screen arrival
  useEffect(() => {
    if (result && result.confidence) {
      const targetPercent = Math.round(result.confidence * 100);
      setAnimatedConfidence(0);
      let current = 0;
      const step = Math.max(1, Math.ceil(targetPercent / 45));
      const timer = setInterval(() => {
        current += step;
        if (current >= targetPercent) {
          setAnimatedConfidence(targetPercent);
          clearInterval(timer);
        } else {
          setAnimatedConfidence(current);
        }
      }, 20);
      return () => clearInterval(timer);
    }
  }, [result]);

  // Handle File Selection
  const handleFileSelect = (file) => {
    if (!file || !file.type.startsWith("image/")) {
      setError("Please select a valid image file (JPEG, PNG, WEBP).");
      return;
    }
    setError(null);
    setSelectedFile(file);
    const reader = new FileReader();
    reader.onload = () => {
      setPreviewUrl(reader.result);
    };
    reader.readAsDataURL(file);
  };

  // Drag & Drop handlers
  const handleDragOver = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileSelect(e.dataTransfer.files[0]);
    }
  };

  // API Call to FastAPI Backend (http://localhost:8000/predict)
  const handleUpload = async (fileToUpload) => {
    const file = fileToUpload || selectedFile;
    if (!file) return;

    setLoading(true);
    setError(null);
    setResult(null);

    const formData = new FormData();
    formData.append("file", file);

    try {
      const res = await fetch("http://localhost:8000/predict", {
        method: "POST",
        body: formData,
      });

      if (!res.ok) {
        const errorData = await res.json().catch(() => ({ detail: "Server error" }));
        throw new Error(errorData.detail || `Server error (${res.status})`);
      }

      const data = await res.json();
      setResult(data);
    } catch (err) {
      console.error("Prediction upload failed:", err);
      setError(err.message || "Failed to connect to FastAPI backend at http://localhost:8000/predict");
    } finally {
      setLoading(false);
    }
  };

  // Preset Sample Image Loader for instant testing
  const loadSampleImage = async (sampleName, label) => {
    try {
      // Generate synthetic sample image using HTML Canvas
      const canvas = document.createElement("canvas");
      canvas.width = 300;
      canvas.height = 300;
      const ctx = canvas.getContext("2d");
      
      // Skin tone background
      ctx.fillStyle = sampleName === "melanoma" ? "#d2a679" : "#e0b084";
      ctx.fillRect(0, 0, 300, 300);

      // Lesion pattern simulation
      const centerX = 150;
      const centerY = 150;
      const gradient = ctx.createRadialGradient(centerX, centerY, 10, centerX, centerY, 80);
      
      if (sampleName === "melanoma") {
        gradient.addColorStop(0, "#1a0d00");
        gradient.addColorStop(0.5, "#4a1c03");
        gradient.addColorStop(0.8, "#8c3b0c");
        gradient.addColorStop(1, "transparent");
      } else {
        gradient.addColorStop(0, "#3d2314");
        gradient.addColorStop(0.6, "#7a4b2a");
        gradient.addColorStop(0.9, "#ad7852");
        gradient.addColorStop(1, "transparent");
      }

      ctx.fillStyle = gradient;
      ctx.beginPath();
      ctx.arc(centerX, centerY, 85, 0, Math.PI * 2);
      ctx.fill();

      canvas.toBlob((blob) => {
        if (blob) {
          const file = new File([blob], `${sampleName}_sample.jpg`, { type: "image/jpeg" });
          handleFileSelect(file);
        }
      }, "image/jpeg");
    } catch (e) {
      console.error("Sample creation failed:", e);
    }
  };

  // Reset screen back to upload state
  const handleReset = () => {
    setSelectedFile(null);
    setPreviewUrl(null);
    setResult(null);
    setError(null);
    setAnimatedConfidence(0);
  };

  // Get badge colors based on severity
  const getSeverityBadge = (severityLevel) => {
    const level = (severityLevel || "").toUpperCase();
    if (level.includes("HIGH")) {
      return {
        bg: "bg-red-500/10 border-red-500/30 text-red-400",
        icon: <ShieldAlert className="w-5 h-5 text-red-400" />,
        label: "HIGH RISK",
        dotColor: "bg-red-500"
      };
    } else if (level.includes("MODERATE")) {
      return {
        bg: "bg-amber-500/10 border-amber-500/30 text-amber-400",
        icon: <AlertTriangle className="w-5 h-5 text-amber-400" />,
        label: "MODERATE RISK",
        dotColor: "bg-amber-500"
      };
    } else {
      return {
        bg: "bg-emerald-500/10 border-emerald-500/30 text-emerald-400",
        icon: <CheckCircle2 className="w-5 h-5 text-emerald-400" />,
        label: "LOW RISK",
        dotColor: "bg-emerald-500"
      };
    }
  };

  return (
    <div className="min-h-[100dvh] flex flex-col font-sans bg-[#090d16] text-slate-100 selection:bg-cyan-500/20 selection:text-cyan-300">
      {/* Header Bar */}
      <header className="sticky top-0 z-40 border-b border-slate-800/60 bg-slate-950/80 backdrop-blur-2xl">
        <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-9 h-9 rounded-xl bg-slate-900 border border-cyan-500/30 flex items-center justify-center shadow-lg shadow-cyan-500/10">
              <Activity className="w-4 h-4 text-cyan-400 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-bold text-base tracking-tight text-white">DermoLens</span>
                <span className="text-[11px] font-mono font-semibold px-2 py-0.5 rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                  v1.0 • EfficientNet-B3
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center space-x-4">
            <div className="hidden md:flex items-center space-x-2 text-xs text-slate-400 bg-slate-900/80 px-3 py-1.5 rounded-lg border border-slate-800/80 font-mono">
              <Cpu className="w-3.5 h-3.5 text-cyan-400" />
              <span>API:</span>
              <span className="text-emerald-400">http://localhost:8000</span>
            </div>
            {result && (
              <button
                onClick={handleReset}
                className="flex items-center space-x-1.5 text-xs font-medium text-slate-300 hover:text-white bg-slate-800/80 hover:bg-slate-800 px-3 py-1.5 rounded-lg border border-slate-700 transition active:scale-[0.98]"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>New Analysis</span>
              </button>
            )}
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-1 max-w-[1400px] w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12 flex flex-col justify-center">
        
        {/* Error Alert */}
        {error && (
          <div className="w-full max-w-3xl mx-auto mb-6 p-4 rounded-xl bg-red-950/40 border border-red-500/30 flex items-start space-x-3 text-red-200 animate-stagger">
            <AlertTriangle className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
            <div className="flex-1 text-sm">
              <p className="font-semibold text-red-300">Connection or Processing Error</p>
              <p className="mt-0.5 text-slate-300">{error}</p>
            </div>
          </div>
        )}

        {/* SCREEN 1: ASYMMETRIC SPLIT-SCREEN UPLOAD (LAYOUT VARIANCE = 8) */}
        {!loading && !result && (
          <div className="w-full grid grid-cols-1 lg:grid-cols-12 gap-8 items-center animate-stagger">
            
            {/* Left Column (7 cols): Asymmetric Left-Aligned Hero Content */}
            <div className="lg:col-span-7 space-y-6">
              <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 text-xs font-mono font-medium">
                <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                <span>Clinical Diagnostic Support Control Plane</span>
              </div>
              
              <div className="space-y-3">
                <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tighter leading-none text-white">
                  Explainable Skin Lesion Diagnostics
                </h1>
                <p className="text-slate-400 text-base sm:text-lg leading-relaxed max-w-[55ch]">
                  High-speed dermatological classification powered by fine-tuned EfficientNet-B3 with automated Grad-CAM heatmaps and clinical severity risk triage.
                </p>
              </div>

              {/* Capabilities Bullet Specs */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                <div className="p-3.5 rounded-xl liquid-glass border border-slate-800/80 flex items-center space-x-3">
                  <Activity className="w-5 h-5 text-cyan-400 shrink-0" />
                  <div>
                    <p className="text-xs font-semibold text-white">Sub-Second Inference</p>
                    <p className="text-[11px] text-slate-400">PyTorch GPU/CPU engine</p>
                  </div>
                </div>
                <div className="p-3.5 rounded-xl liquid-glass border border-slate-800/80 flex items-center space-x-3">
                  <Eye className="w-5 h-5 text-emerald-400 shrink-0" />
                  <div>
                    <p className="text-xs font-semibold text-white">Grad-CAM XAI Heatmaps</p>
                    <p className="text-[11px] text-slate-400">Visual activation opacity</p>
                  </div>
                </div>
              </div>

              {/* Preset Sample Selector */}
              <div className="pt-2 flex flex-wrap items-center gap-2">
                <span className="text-xs font-medium text-slate-400">Quick Test Samples:</span>
                <button
                  type="button"
                  onClick={() => loadSampleImage("nevus", "Nevus")}
                  className="px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 hover:border-cyan-500/40 text-xs text-slate-300 hover:text-white transition active:scale-[0.98]"
                >
                  Benign Nevus
                </button>
                <button
                  type="button"
                  onClick={() => loadSampleImage("melanoma", "Melanoma")}
                  className="px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 hover:border-cyan-500/40 text-xs text-slate-300 hover:text-white transition active:scale-[0.98]"
                >
                  Melanoma
                </button>
              </div>
            </div>

            {/* Right Column (5 cols): Liquid Glass Dropzone Surface */}
            <div className="lg:col-span-5 space-y-4">
              <div
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
                onClick={() => fileInputRef.current?.click()}
                className={`w-full liquid-glass-interactive rounded-3xl p-8 sm:p-10 flex flex-col items-center justify-center cursor-pointer relative overflow-hidden group border-2 border-dashed ${
                  isDragging
                    ? "border-cyan-400 bg-cyan-950/20 scale-[1.01]"
                    : selectedFile
                    ? "border-cyan-500/50 bg-slate-900/80"
                    : "border-slate-800/80 hover:border-cyan-500/40"
                }`}
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/jpeg,image/png,image/webp"
                  className="hidden"
                  onChange={(e) => e.target.files && handleFileSelect(e.target.files[0])}
                />

                {previewUrl ? (
                  <div className="flex flex-col items-center space-y-4 w-full">
                    <div className="relative w-48 h-48 rounded-2xl overflow-hidden border border-cyan-500/40 shadow-2xl group-hover:scale-105 transition duration-300">
                      <img
                        src={previewUrl}
                        alt="Lesion Preview"
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute inset-0 bg-slate-950/50 opacity-0 group-hover:opacity-100 transition flex items-center justify-center text-xs text-white font-medium">
                        Click to change image
                      </div>
                    </div>
                    <div className="text-center">
                      <p className="text-sm font-semibold text-white truncate max-w-[220px]">{selectedFile?.name}</p>
                      <p className="text-xs text-slate-400 font-mono mt-0.5">
                        {(selectedFile?.size / 1024).toFixed(1)} KB • Ready
                      </p>
                    </div>
                  </div>
                ) : (
                  <div className="flex flex-col items-center space-y-4 text-center py-4">
                    <div className="w-16 h-16 rounded-2xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400 group-hover:scale-110 transition duration-300 shadow-inner">
                      <Upload className="w-7 h-7" />
                    </div>
                    <div>
                      <p className="text-base font-semibold text-slate-200">
                        Drop dermoscopic image here
                      </p>
                      <p className="text-xs text-slate-400 mt-1 max-w-[260px]">
                        Macro skin scans (JPEG, PNG, WEBP)
                      </p>
                    </div>
                    <span className="text-xs font-medium text-cyan-400 bg-cyan-950/60 border border-cyan-500/30 px-4 py-1.5 rounded-full group-hover:bg-cyan-500 group-hover:text-slate-950 transition">
                      Browse File
                    </span>
                  </div>
                )}
              </div>

              {/* Submit CTA */}
              <button
                disabled={!selectedFile}
                onClick={() => handleUpload()}
                className={`w-full py-3.5 rounded-2xl font-semibold text-sm flex items-center justify-center space-x-2 transition shadow-xl active:scale-[0.98] ${
                  selectedFile
                    ? "bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-white shadow-cyan-500/20 cursor-pointer"
                    : "bg-slate-900 text-slate-600 cursor-not-allowed border border-slate-800/80"
                }`}
              >
                <span>Execute Diagnostic Inference</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>

          </div>
        )}

        {/* SCREEN 2: LOADING SCREEN WITH CYCLING STATUS TEXT */}
        {loading && (
          <div className="w-full max-w-md glass-card rounded-2xl p-10 flex flex-col items-center text-center space-y-8 animate-fade-scale shadow-2xl">
            
            {/* Visual Radar Scanner */}
            <div className="relative w-40 h-40 rounded-2xl overflow-hidden border border-cyan-500/40 bg-slate-900 flex items-center justify-center shadow-inner">
              {previewUrl && (
                <img
                  src={previewUrl}
                  alt="Analyzing Lesion"
                  className="w-full h-full object-cover opacity-60"
                />
              )}
              {/* Radar scanner line overlay */}
              <div className="absolute inset-x-0 h-1 bg-gradient-to-r from-transparent via-cyan-400 to-transparent shadow-[0_0_15px_#22d3ee] animate-scan" />
              <div className="absolute inset-0 bg-gradient-to-b from-cyan-500/10 via-transparent to-cyan-500/10" />
            </div>

            {/* Cycling Status Indicator */}
            <div className="space-y-3 w-full">
              <div className="flex items-center justify-center space-x-2 text-cyan-400 font-mono text-xs font-semibold uppercase tracking-wider">
                <Activity className="w-4 h-4 animate-spin text-cyan-400" />
                <span>Processing Neural Pipeline</span>
              </div>
              
              <p className="text-base font-semibold text-white h-12 flex items-center justify-center px-4 transition-all duration-300">
                {CYCLING_STATUSES[statusIndex]}
              </p>

              {/* Smooth Loading Progress Bar */}
              <div className="w-full bg-slate-900 rounded-full h-2 overflow-hidden border border-slate-800">
                <div 
                  className="bg-gradient-to-r from-cyan-500 to-indigo-500 h-full transition-all duration-500 ease-out"
                  style={{ width: `${((statusIndex + 1) / CYCLING_STATUSES.length) * 100}%` }}
                />
              </div>
              <p className="text-xs text-slate-500 font-mono">
                Model: EfficientNet-B3 • FastAPI Startup Global Loader
              </p>
            </div>
          </div>
        )}

        {/* SCREEN 3: RESULTS SCREEN */}
        {!loading && result && (
          <div className="w-full max-w-[1400px] space-y-6 animate-stagger">
            
            {/* Top Diagnostic Summary Bar */}
            <div className="liquid-glass rounded-3xl p-6 sm:p-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-6 border-l-4 border-l-cyan-400">
              <div className="space-y-1">
                <div className="flex items-center space-x-3">
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Predicted Lesion Class</span>
                  {/* Severity Risk Badge */}
                  {(() => {
                    const badge = getSeverityBadge(result.severity);
                    return (
                      <span className={`inline-flex items-center space-x-1.5 px-3 py-1 rounded-full text-xs font-semibold border ${badge.bg}`}>
                        <span className={`w-2 h-2 rounded-full ${badge.dotColor} animate-ping`} />
                        <span>{badge.label}</span>
                      </span>
                    );
                  })()}
                </div>
                <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
                  {result.prediction}
                </h2>
                <p className="text-xs text-slate-400 font-mono">
                  Class Code: <span className="text-cyan-400 font-bold uppercase">{result.class_code}</span>
                </p>
              </div>

              {/* Confidence Counter Card */}
              <div className="flex items-center space-x-4 bg-slate-900/90 border border-slate-800 p-4 rounded-xl min-w-[220px]">
                <div className="space-y-1 flex-1">
                  <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Model Confidence</p>
                  <p className="text-3xl font-black text-white font-mono">
                    {animatedConfidence}%
                  </p>
                  {/* Confidence Bar */}
                  <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                    <div 
                      className="bg-gradient-to-r from-cyan-500 to-indigo-500 h-full transition-all duration-700 ease-out"
                      style={{ width: `${animatedConfidence}%` }}
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Split Screen Grid: Grad-CAM Viewer (Left) + Clinical Details (Right) */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              
              {/* Left Column (7 cols): Grad-CAM Heatmap Cross-Fade Toggle */}
              <div className="lg:col-span-7 liquid-glass rounded-3xl p-6 flex flex-col space-y-5">
                <div className="flex items-center justify-between border-b border-slate-800/80 pb-4">
                  <div className="flex items-center space-x-2">
                    <Eye className="w-5 h-5 text-cyan-400" />
                    <h3 className="font-semibold text-white text-base">Grad-CAM Explainable AI Visualizer</h3>
                  </div>
                  
                  {/* View Mode Toggle Switch */}
                  <div className="flex bg-slate-900 p-1 rounded-lg border border-slate-800 text-xs font-medium">
                    <button
                      onClick={() => setViewMode("original")}
                      className={`px-3 py-1.5 rounded-md transition ${
                        viewMode === "original"
                          ? "bg-cyan-500 text-slate-950 font-bold"
                          : "text-slate-400 hover:text-white"
                      }`}
                    >
                      Original
                    </button>
                    <button
                      onClick={() => setViewMode("overlay")}
                      className={`px-3 py-1.5 rounded-md transition ${
                        viewMode === "overlay"
                          ? "bg-cyan-500 text-slate-950 font-bold"
                          : "text-slate-400 hover:text-white"
                      }`}
                    >
                      Overlay
                    </button>
                    <button
                      onClick={() => setViewMode("heatmap")}
                      className={`px-3 py-1.5 rounded-md transition ${
                        viewMode === "heatmap"
                          ? "bg-cyan-500 text-slate-950 font-bold"
                          : "text-slate-400 hover:text-white"
                      }`}
                    >
                      Heatmap
                    </button>
                  </div>
                </div>

                {/* Interactive Image Cross-Fade Overlay Display */}
                <div className="relative aspect-square w-full max-w-md mx-auto rounded-xl overflow-hidden border border-slate-800 bg-slate-950 shadow-2xl">
                  {/* Base Original Image */}
                  <img
                    src={result.original_image || previewUrl}
                    alt="Original Lesion"
                    className="absolute inset-0 w-full h-full object-cover"
                  />

                  {/* Heatmap Layer with Cross-Fade Opacity transition */}
                  {(viewMode === "overlay" || viewMode === "heatmap") && (
                    <img
                      src={result.heatmap}
                      alt="Grad-CAM Heatmap Overlay"
                      className="absolute inset-0 w-full h-full object-cover transition-opacity duration-500 ease-in-out"
                      style={{ 
                        opacity: viewMode === "heatmap" ? 1.0 : opacity 
                      }}
                    />
                  )}

                  {/* Heatmap Legend Badge */}
                  <div className="absolute bottom-3 left-3 right-3 bg-slate-950/80 backdrop-blur-md px-3 py-2 rounded-lg border border-slate-800 flex items-center justify-between text-xs">
                    <span className="text-slate-400 font-mono">Heatmap Activation</span>
                    <div className="flex items-center space-x-1">
                      <span className="text-[10px] text-blue-400 font-mono">Low</span>
                      <div className="w-16 h-2 rounded-full bg-gradient-to-r from-blue-600 via-yellow-400 to-red-600" />
                      <span className="text-[10px] text-red-400 font-mono">High</span>
                    </div>
                  </div>
                </div>

                {/* Opacity Blending Slider (Available in Overlay Mode) */}
                {viewMode === "overlay" && (
                  <div className="bg-slate-900/60 p-4 rounded-xl border border-slate-800/80 space-y-2">
                    <div className="flex items-center justify-between text-xs text-slate-400">
                      <span className="flex items-center space-x-1.5 font-medium">
                        <Sliders className="w-3.5 h-3.5 text-cyan-400" />
                        <span>Grad-CAM Blend Intensity</span>
                      </span>
                      <span className="font-mono text-cyan-400 font-bold">{Math.round(opacity * 100)}%</span>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max="1"
                      step="0.05"
                      value={opacity}
                      onChange={(e) => setOpacity(parseFloat(e.target.value))}
                      className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
                    />
                  </div>
                )}
              </div>

              {/* Right Column (5 cols): Severity Details & Multiclass Matrix */}
              <div className="lg:col-span-5 flex flex-col space-y-6">
                
                {/* Clinical Severity & Action Card */}
                <div className="liquid-glass rounded-3xl p-6 space-y-4">
                  <div className="flex items-center space-x-2 border-b border-slate-800/80 pb-3">
                    <FileText className="w-5 h-5 text-indigo-400" />
                    <h3 className="font-semibold text-white text-base">Clinical Action & Recommendation</h3>
                  </div>

                  {result.severity_details && (
                    <div className="space-y-3">
                      <div className="p-3.5 rounded-xl bg-slate-900/90 border border-slate-800 text-sm text-slate-300 leading-relaxed">
                        <p className="font-medium text-white mb-1">
                          {result.severity_details.summary}
                        </p>
                        <p className="text-xs text-slate-400">
                          {result.severity_details.recommendation}
                        </p>
                      </div>
                    </div>
                  )}
                </div>

                {/* Multiclass Probability Breakdown */}
                {result.class_probabilities && (
                  <div className="liquid-glass rounded-3xl p-6 space-y-4 flex-1">
                    <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
                      <div className="flex items-center space-x-2">
                        <Layers className="w-5 h-5 text-cyan-400" />
                        <h3 className="font-semibold text-white text-base">Class Probability Distribution</h3>
                      </div>
                    </div>

                    <div className="space-y-3">
                      {result.class_probabilities.map((item, idx) => (
                        <div key={idx} className="space-y-1 text-xs">
                          <div className="flex items-center justify-between text-slate-300">
                            <span className="font-medium truncate max-w-[200px]">{item.name}</span>
                            <span className="font-mono font-bold text-slate-400">{item.percentage}%</span>
                          </div>
                          <div className="w-full bg-slate-900 h-1.5 rounded-full overflow-hidden border border-slate-800">
                            <div
                              className={`h-full rounded-full transition-all duration-500 ${
                                idx === 0 
                                  ? "bg-gradient-to-r from-cyan-500 to-indigo-500" 
                                  : "bg-slate-700"
                              }`}
                              style={{ width: `${item.percentage}%` }}
                            />
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

              </div>
            </div>

          </div>
        )}

      </main>

      {/* Footer */}
      <footer className="border-t border-slate-900 py-4 bg-slate-950 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <p>DermoLens AI • PyTorch EfficientNet-B3 Skin Lesion Diagnostic Control Plane</p>
          <p className="text-slate-600">Model loaded globally on startup via FastAPI</p>
        </div>
      </footer>
    </div>
  );
}
